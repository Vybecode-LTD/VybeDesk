# Debug Feature Inventory — ProjectsView + HomeView

Saved at 2026-05-25 so both views can be stripped to header-only for
isolation testing without losing track of what needs to be restored.

## ProjectsView feature inventory

### Structure
- Root: `DockPanel LastChildFill="True"`
- ModuleHeader: `DockPanel.Dock="Top"`, binds `StatusMessage`
- Left rail: `Border DockPanel.Dock="Left" Width="340" Background="#22222A"`
- Right pane: `ScrollViewer` as DockPanel fill child

### Left rail contents
1. **"New project" button** — `Command="{Binding NewProjectCommand}"`, `IsEnabled="{Binding IsNotBusy}"`
2. **"Import existing…" button** — `Command="{Binding ImportExistingCommand}"`, `IsEnabled="{Binding IsNotBusy}"`, tooltip about `.claude/` ingestion
3. **Project ListBox** — `ItemsSource="{Binding Projects}"`, `SelectedItem="{Binding SelectedProject}"`, transparent background, no border
   - Item template: Name (SemiBold, CharacterEllipsis) + FolderPath (FontSize=10, Opacity=0.45, CharacterEllipsis)

### Right pane contents (inside ScrollViewer > StackPanel Spacing="16" MaxWidth="640")
1. **Empty-state text** — "Select a project…", `IsVisible="{Binding !HasSelection}"`
2. **Editor panel** — `IsVisible="{Binding HasSelection}"`, contains:
   a. **"Edit project" heading** — FontSize=18, SemiBold
   b. **Name field** — label + `TextBox Text="{Binding EditName}"`
   c. **Description field** — label + multiline TextBox (`AcceptsReturn`, `TextWrapping="Wrap"`, `MinHeight="80"`, `MaxHeight="200"`)
   d. **Folder path field** — label + `Grid ColumnDefinitions="*,Auto"` with TextBox + Browse button (`BrowseFolderCommand`)
   e. **Status field** — label + `ComboBox ItemsSource="{Binding Statuses}"`, `SelectedItem="{Binding EditStatus}"`
   f. **Logo path field** — label + `Grid ColumnDefinitions="*,Auto"` with TextBox + Browse button (`BrowseLogoPathCommand`)
   g. **Model override** — label + ComboBox (custom ItemTemplate showing DisplayName + Tier) + freeform TextBox for custom model ID
   h. **Default output path** — label + `Grid ColumnDefinitions="*,Auto"` with TextBox + Browse button (`BrowseDefaultOutputPathCommand`)
   i. **Action buttons** — horizontal: Save, Delete, Open in Claude Code (all `IsEnabled="{Binding IsNotBusy}"`)

## HomeView feature inventory

### Structure
- Root: `DockPanel LastChildFill="True"`
- ModuleHeader: `DockPanel.Dock="Top"`, no extra bindings
- Content: `ScrollViewer` as DockPanel fill child

### Content (inside ScrollViewer > StackPanel Spacing="14" MaxWidth="960")
1. **Empty-state text** — "No projects yet…", `IsVisible="{Binding !Cards.Count}"`
2. **Card list** — `ItemsControl ItemsSource="{Binding PagedCards}"` with card template:
   - Each card is a `Button Classes="home-card"` wrapping a `Border Background="#2F2F38" CornerRadius="8" Padding="18"`
   - `Command="{Binding $parent[ItemsControl].((vm:HomeViewModel)DataContext).OpenProjectCommand}"`
   - Inside each card:
     a. **Name row** — `Grid ColumnDefinitions="44,*,Auto"` with 36x36 logo slot (Image or folder glyph fallback), Name text, arrow
     b. **Description** — wrapping, max 2 lines, ellipsis
     c. **Folder path** — monospace, ellipsis
     d. **Metrics row** — horizontal StackPanel with 4 metric badges:
        - Stale docs (red, `#3A2126` bg)
        - Commits 7d (blue, `#1F2A3A` bg)
        - Pending actions (amber, `#3A2F1F` bg)
        - Last activity (`#2A2A33` bg)
     e. **Loading text** — "Loading metrics…", `IsVisible="{Binding IsLoading}"`
     f. **Error text** — "(Metrics failed…)", `IsVisible="{Binding LoadFailed}"`
3. **Pagination** — horizontal StackPanel, centered, `IsVisible="{Binding HasMultiplePages}"`
   - Previous button, page label, Next button

### Local styles
- `Button.home-card` — transparent bg, no border, rounded corners, hand cursor
- `Button.home-card:pointerover` — transparent bg, opacity 0.92

## Files saved
- `docs/debug/ProjectsView-FULL-SNAPSHOT.axaml` — complete ProjectsView XAML
- `docs/debug/HomeView-FULL-SNAPSHOT.axaml` — complete HomeView XAML
- `docs/debug/DEBUG-FEATURE-INVENTORY.md` — this file
