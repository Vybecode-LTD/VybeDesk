using System.Runtime.Versioning;
using Avalonia;
using ClaudePM.App.Services;
using ClaudePM.App.ViewModels;
using ClaudePM.Core.Services;
using ClaudePM.Services.Agent;
using ClaudePM.Services.Ai;
using ClaudePM.Services.Docs;
using ClaudePM.Services.Import;
using ClaudePM.Services.ProjectHealth;
using ClaudePM.Services.Security;
using ClaudePM.Services.Session;
using ClaudePM.Services.Settings;
using ClaudePM.Services.Skills;
using ClaudePM.Services.Storage;
using ClaudePM.Services.Testing;
using ClaudePM.Services.Vision;
using Microsoft.Extensions.DependencyInjection;

namespace ClaudePM.App;

[SupportedOSPlatform("windows")]
internal static class Program
{
    /// <summary>The composition root. Resolved from App.axaml.cs only.</summary>
    public static IServiceProvider Services { get; private set; } = null!;

    [STAThread]
    public static void Main(string[] args)
    {
        var sc = new ServiceCollection();
        ConfigureServices(sc);
        Services = sc.BuildServiceProvider();

        try
        {
            BuildAvaloniaApp().StartWithClassicDesktopLifetime(args);
        }
        finally
        {
            (Services as IDisposable)?.Dispose();
        }
    }

    private static void ConfigureServices(IServiceCollection s)
    {
        // Infrastructure
        s.AddSingleton<Database>();
        s.AddSingleton<ISecureKeyStore, DpapiKeyStore>();
        s.AddSingleton<ISettingsService, JsonSettingsService>();
        s.AddSingleton<IProjectStore, SqliteProjectStore>();
        s.AddSingleton<IPromptStore, SqlitePromptStore>();
        s.AddSingleton<INoteStore, SqliteNoteStore>();
        s.AddSingleton<IBugStore, SqliteBugStore>();
        s.AddSingleton<ITestingPlanStore, SqliteTestingPlanStore>();
        s.AddSingleton<ITestingFrameworkCatalog, TestingFrameworkCatalog>();
        s.AddSingleton<IBugFixedNotifier, BugFixedNotifier>();
        s.AddSingleton<INotebookOpener, NotebookOpener>();
        s.AddSingleton<IHomeNavigator, HomeNavigator>();
        // M4 #16: tracks the currently-focused project across modules so
        // AnthropicChatService can resolve a per-project Model override.
        s.AddSingleton<IActiveProjectContext, ActiveProjectContext>();
        s.AddSingleton<IVisionStore, SqliteVisionStore>();
        s.AddSingleton<IAuditHistoryStore, SqliteAuditHistoryStore>();
        s.AddSingleton<IAgentActionLogStore, SqliteAgentActionLogStore>();
        s.AddSingleton<IAiCallStore, SqliteAiCallStore>();
        s.AddSingleton<IVisionAuditService, VisionAuditService>();
        s.AddSingleton<IAiService, AnthropicChatService>();
        s.AddSingleton<IDocReconciliationService, DocReconciliationService>();
        s.AddSingleton<IAgentActionService, AgentActionService>();
        s.AddSingleton<ISkillLibraryService, SkillLibraryService>();
        s.AddSingleton<ISkillBuilderService, SkillBuilderService>();
        s.AddSingleton<ISessionBuilderService, SessionBuilderService>();
        s.AddSingleton<IProjectImportService, ProjectImportService>();
        s.AddSingleton<IProjectHealthService, ProjectHealthService>();
        s.AddSingleton<IFilePickerService, AvaloniaFilePickerService>();
        s.AddSingleton<IClaudeCodeLauncher, ClaudeCodeLauncher>();
        s.AddSingleton<IClipboardService, AvaloniaClipboardService>();

        // Page view models (one per module + Home + Projects + Settings)
        s.AddSingleton<HomeViewModel>();
        s.AddSingleton<ProjectsViewModel>();
        s.AddSingleton<DocumentationViewModel>();
        s.AddSingleton<PromptManagerViewModel>();
        s.AddSingleton<SessionBuilderViewModel>();
        s.AddSingleton<NotebookViewModel>();
        s.AddSingleton<BugTrackerViewModel>();
        s.AddSingleton<TestingManagerViewModel>();
        s.AddSingleton<VisionAuditViewModel>();
        // Skill area — Section hosts Manager + Builder sub-pages. The
        // Section's constructor takes an optional PageViewModel builder; we
        // resolve SkillBuilderViewModel and pass it in via a factory
        // registration so the section's in-pane toggle lights up the
        // Builder tab automatically (Phase 2 of the Skills rebuild).
        s.AddSingleton<SkillManagerViewModel>();
        s.AddSingleton<SkillBuilderViewModel>();
        s.AddSingleton<SkillSectionViewModel>(sp => new SkillSectionViewModel(
            sp.GetRequiredService<SkillManagerViewModel>(),
            sp.GetRequiredService<SkillBuilderViewModel>()));
        s.AddSingleton<SettingsViewModel>();

        // Shell
        s.AddSingleton<MainWindowViewModel>();
    }

    public static AppBuilder BuildAvaloniaApp()
        => AppBuilder.Configure<App>()
            .UsePlatformDetect()
            .WithInterFont()
            .LogToTrace();
}
