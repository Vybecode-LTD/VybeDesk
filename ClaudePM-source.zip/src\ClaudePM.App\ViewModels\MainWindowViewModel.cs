using System.Collections.ObjectModel;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.ComponentModel;

namespace ClaudePM.App.ViewModels;

/// <summary>The shell. Owns the navigable page list and the current page.</summary>
public partial class MainWindowViewModel : ViewModelBase
{
    public ObservableCollection<PageViewModel> Pages { get; }

    [ObservableProperty]
    private PageViewModel _currentPage;

    public MainWindowViewModel(
        HomeViewModel home,
        ProjectsViewModel projects,
        DocumentationViewModel documentation,
        PromptManagerViewModel prompts,
        SessionBuilderViewModel sessionBuilder,
        NotebookViewModel notebook,
        SkillSectionViewModel skills,
        BugTrackerViewModel bugs,
        TestingManagerViewModel testing,
        VisionAuditViewModel vision,
        SettingsViewModel settings)
    {
        Pages = new ObservableCollection<PageViewModel>
        {
            home, projects, documentation, prompts, sessionBuilder, notebook, skills, bugs, testing, vision, settings,
        };
        _currentPage = home;
    }

    /// <summary>
    /// Intercepts selection of group nodes (pages with non-empty
    /// <see cref="PageViewModel.Children"/>). When the user clicks a group
    /// node in the sidebar TreeView (e.g. the Skills parent row), we
    /// re-route the selection to the group's first child so the content
    /// area never tries to render a bare group node that has no view.
    ///
    /// <see cref="Dispatcher.UIThread"/> <c>Post</c> is used rather than a
    /// direct assignment because mutating <see cref="CurrentPage"/> inside
    /// its own setter would re-enter the source-generator's change-
    /// notification path and confuse the TreeView's two-way binding. Posting
    /// to the dispatcher lets the current setter complete first, then the
    /// re-route runs on the next UI tick — the user perceives a single
    /// instant click.
    /// </summary>
    partial void OnCurrentPageChanged(PageViewModel? oldValue, PageViewModel newValue)
    {
        // _currentPage's field type is non-nullable PageViewModel, so the
        // source generator emits this with a non-nullable second parameter.
        if (newValue.Children.Count > 0)
        {
            var defaultChild = newValue.Children[0];
            Dispatcher.UIThread.Post(() => CurrentPage = defaultChild);
        }
    }
}
